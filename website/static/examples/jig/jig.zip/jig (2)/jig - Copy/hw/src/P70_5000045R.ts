import { Component, Pin } from "@typecad/typecad";
/**
 | Pin # | Name | Type          |
 | --:   | :--  | :--           |
 | 1     | _1  | passive      |
 */

 interface IP70_5000045R {
    reference?: string,
    footprint?: string,
    uuid?: string,
    pcb?: { x: number, y: number, rotation: number }
}

export class P70_5000045R extends Component {
    _1 = new Pin(this.reference, 1, 'passive', this);
    
    constructor({ reference, footprint, uuid, pcb }: IP70_5000045R = {}) {
        super({ reference, footprint: "lib:HARWIN_P70-5000045R", symbol: 'P70-5000045R:P70-5000045R', uuid, pcb });
    }
}