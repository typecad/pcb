import { PCB } from "@typecad/typecad"
import { Resistor } from '@typecad/passives/0603';
import { MountingHole } from '@typecad/passives/mounting_hole';
import { Testpoint } from '@typecad/passives/testpoint';
import { P70_5000045R } from './P70_5000045R';

let typecad = new PCB('main');

let r1 = new Resistor({ value: '1kohm', pcb: {x: 166.815, y: 86.36, rotation: 0} });
let mh1 = new MountingHole({ size: 'M2.5', pcb: {x: 152.4, y: 76.2, rotation: 0} });
let mh2 = new MountingHole({ size: 'M2.5',  pcb: {x: 177.8, y: 101.6, rotation: 0} });

let tp1 = new Testpoint({  pcb: {x: 165.1, y: 81.28, rotation: 0} });
let tp2 = new Testpoint({  pcb: {x: 168.04, y: 93.98, rotation: 0} });

typecad.create(r1, mh1, mh2, tp1, tp2);

let jig = new PCB('jig');
let pogo1 = new P70_5000045R({  pcb: {x: 165.1, y: 81.28, rotation: 0} });
let pogo2 = new P70_5000045R({  pcb: {x: 168.04, y: 93.98, rotation: 0} });

jig.create(mh1, mh2, pogo1, pogo2);
